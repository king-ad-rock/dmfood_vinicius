package br.com.cetam.dmfood.service;

import br.com.cetam.dmfood.domain.usuario.DadosUsuarioCadastro;
import br.com.cetam.dmfood.domain.usuario.Usuario;
import br.com.cetam.dmfood.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UsuarioService {
    @Autowired
    private UsuarioRepository usuarioRepository;

    public Usuario cadastrarUsuario(DadosUsuarioCadastro dados) {
        Usuario usuario = new Usuario(dados);
        return usuarioRepository.save(usuario);
    }

}
