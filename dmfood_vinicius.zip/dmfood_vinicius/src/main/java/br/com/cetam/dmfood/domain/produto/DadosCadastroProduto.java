package br.com.cetam.dmfood.domain.produto;

public record DadosCadastroProduto(
        String nome,
        String descricao,
        String categoria
) {

}
