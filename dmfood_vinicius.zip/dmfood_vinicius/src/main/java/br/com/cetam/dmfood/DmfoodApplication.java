package br.com.cetam.dmfood;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DmfoodApplication {

	public static void main(String[] args) {
		SpringApplication.run(DmfoodApplication.class, args);
	}

}
