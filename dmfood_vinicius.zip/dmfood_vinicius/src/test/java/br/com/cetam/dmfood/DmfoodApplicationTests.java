package br.com.cetam.dmfood;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DmfoodApplicationTests {

	@Test
	void contextLoads() {
	}

}
