package br.com.cetam.dmfood.domain.usuario;

import java.time.LocalDate;

public record DadosUsuarioCadastro(
        String username,
        String password,
        String estadoLogin,
        LocalDate dataCadastro
) {
    public DadosUsuarioCadastro(Usuario usuario){
        this(
                usuario.getUsername(), usuario.getPassword(), usuario.getEstadoLogin(), usuario.getDataCadastro()
        );
    }
}
