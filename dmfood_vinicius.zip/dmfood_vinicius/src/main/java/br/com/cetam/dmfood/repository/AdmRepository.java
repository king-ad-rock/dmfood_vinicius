package br.com.cetam.dmfood.repository;

import br.com.cetam.dmfood.domain.adm.Adm;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdmRepository extends JpaRepository<Adm, Long> {
}
