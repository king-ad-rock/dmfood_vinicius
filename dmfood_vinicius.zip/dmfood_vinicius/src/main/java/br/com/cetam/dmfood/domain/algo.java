package br.com.cetam.dmfood.domain;

public class algo {
}
